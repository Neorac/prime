import 'package:flutter/material.dart';
import '../AllScreens/supportCenterScreen.dart';
import '../AllScreens/editProfileScreen.dart';

class EvaluationsScreen extends StatefulWidget {

  static const String idScreen = "EvaluationsScreen";

  @override
  _EvaluationsScreenState createState() => _EvaluationsScreenState();
}

class _EvaluationsScreenState extends State<EvaluationsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        title: Text("Evaluations", style: TextStyle( fontFamily: "Avenir",),),
        leading: IconButton(
          onPressed: () {
            Navigator.pushNamedAndRemoveUntil(context, EditProfileScreen.idScreen, (route) => false);
          },
          icon: Icon(
            Icons.arrow_back_ios,
            color: Colors.black,
          ),
        ),
      ),
      body: Container(
        padding: EdgeInsets.only(left: 25, top: 25, right: 25,),
        child: ListView(
          children: [
            SizedBox(height: 10.0,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, SupportCenterPage.idScreen, (route) => false);
            },
              child: Container(
                height: 155,
                alignment: Alignment.center,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child:
                Text("Psychopathic Evaluation",
                  style: TextStyle(
                    fontFamily: "Avenir",
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
            SizedBox(height: 2,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, SupportCenterPage.idScreen, (route) => false);
            },
              child: Container(
                height: 155,
                alignment: Alignment.center,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child:
                Text("Psychiatric Evaluation",
                  style: TextStyle(
                    fontFamily: "Avenir",
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
            SizedBox(height: 2,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, SupportCenterPage.idScreen, (route) => false);
            },
              child: Container(
                height: 155,
                alignment: Alignment.center,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),),
                child:
                Text("Empathic Evaluation",
                  style: TextStyle(
                    fontFamily: "Avenir",
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
            SizedBox(height: 2,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, SupportCenterPage.idScreen, (route) => false);
            },
              child: Container(
                height: 155,
                alignment: Alignment.center,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child:
                    Text("I.Q Evaluation",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                ),
            ),
            SizedBox(height: 15.0,),
          ],
        ),
      ),
    );
  }
}