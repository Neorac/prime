import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../AllScreens/settingsScreen.dart';
import '../AllScreens/loginScreen.dart';
import '../AllScreens/supportCenterScreen.dart';

class LoginInfoPage extends StatefulWidget {

  static const String idScreen = "LoginInfoPage";

  @override
  _LoginInfoPageState createState() => _LoginInfoPageState();
}

class _LoginInfoPageState extends State<LoginInfoPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        title: Text("Login Info", style: TextStyle( fontFamily: "Avenir",),),
        leading: IconButton(
          onPressed: () {
            Navigator.pushNamedAndRemoveUntil(context, SettingsPage.idScreen, (route) => false);
          },
          icon: Icon(
            Icons.arrow_back_ios,
            color: Colors.black,
          ),
        ),
      ),
      body: Container(
        padding: EdgeInsets.only(left: 25, top: 25, right: 25,),
        child: ListView(
          children: [
            SizedBox(height: 10.0,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, SupportCenterPage.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Login activities",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 2,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, SupportCenterPage.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                  //boxShadow: [BoxShadow(color: Colors.black12, offset: Offset(2.0, 2.0), blurRadius: 1.0, spreadRadius: 1.0,)]
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("User information",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 2,),
            GestureDetector( onTap: (){
              showDialog(context: context, builder: (BuildContext context){
                return AlertDialog(
                  title: Text("Confirm Log Out?", style: TextStyle( fontFamily: "Avenir",),),
                  actions: <Widget>[
                    FlatButton(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text("Log out", style: TextStyle( fontFamily: "Avenir",),),
                      color: Colors.red,
                      textColor: Colors.white,
                      onPressed: () async {
                        FirebaseAuth.instance.signOut();
                        Navigator.pushNamedAndRemoveUntil(
                            context, loginScreen.idScreen, (route) => false);
                        },
                    ),
                  ],
                );
              });
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Log out user",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        color: Colors.red,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.red,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 15.0,),
          ],
        ),
      ),
    );
  }
}