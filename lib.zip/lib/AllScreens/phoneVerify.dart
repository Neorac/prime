import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../AllScreens/mainScreen.dart';

enum MobileVerificationState{
  SHOW_MOBILE_FORM_STATE,
  SHOW_OTP_FORM_STATE,
}
class PhoneVerification extends StatefulWidget {

  static const String idScreen = "PhoneVerification";

  @override
  _PhoneVerificationState createState() => _PhoneVerificationState();
}

class _PhoneVerificationState extends State<PhoneVerification> {

  MobileVerificationState currentState = MobileVerificationState.SHOW_MOBILE_FORM_STATE;

  final phoneController = TextEditingController();
  final otpController = TextEditingController();

  FirebaseAuth _auth = FirebaseAuth.instance;

  String verificationId;

  bool showLoading = false;

  void signInWithPhoneAuthCredential(PhoneAuthCredential phoneAuthCredential) async {

    setState(() {
      showLoading = true;
    });

    try {
      final authCredential =
      await _auth.signInWithCredential(phoneAuthCredential);
      setState(() {
        showLoading = false;
      });
      if(authCredential?.user != null){
        Navigator.push(context, MaterialPageRoute(builder: (context)=> MainScreen()));
      }
    } on FirebaseAuthException catch (e) {
      setState(() {
        showLoading = false;
      });
      _scaffoldKey.currentState
          .showSnackBar(SnackBar(content: Text(e.message),));
    }
  }
  getMobileFormWidget(context) {
    return SimpleDialog(
      contentPadding: EdgeInsets.symmetric(
        horizontal: 25,
        vertical: 20,
      ),
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      title: Row(
        children: [
          Text(
            "Verify Contact",
            style: TextStyle(
              fontFamily: "Avenir",
              fontSize: 20,
              color: Colors.black54,
            ),
          ),
          Spacer(),
          IconButton(
            icon: Icon(
              Icons.cancel,
              color: Colors.grey,
              size: 30,
            ),
            onPressed: () => Navigator.pop(context),
          )
        ],
      ),
        children: [
          Divider(),
          TextFormField(
            controller: phoneController,
            style: TextStyle(
              fontSize: 18,
              height: 1.5,
              color: Colors.black,
            ),
            autofocus: true,
            decoration: InputDecoration(
              hintText: "Phone Number",
              hintStyle: TextStyle( fontFamily: "Avenir", color: Colors.grey[400]),
              border: InputBorder.none,
            ),
          ),
          SizedBox(height: 20),
          SizedBox(width: 70, height: 50,
            child: FlatButton(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              onPressed: () async {
                setState(() {
                  showLoading = true;
                });
                await _auth.verifyPhoneNumber (
                  phoneNumber: phoneController.text,
                  verificationCompleted: (phoneAuthCredential) async{
                    setState(() {
                      showLoading = false;
                    });
                    //signInWithPhoneAuthCredential(phoneAuthCredential);
                  },
                  verificationFailed: (verificationFailed) async{
                    _scaffoldKey.currentState.showSnackBar(SnackBar(content: Text(verificationFailed.message)));
                  },
                  codeSent: (verificationId, resendingToken) async{
                    setState(() {
                      showLoading = false;
                      currentState = MobileVerificationState.SHOW_OTP_FORM_STATE;
                      this.verificationId = verificationId;
                    });
                  },
                  codeAutoRetrievalTimeout: (verificationId) async{
                  },
                );
              },
              child: Text("Click to Verify", style: TextStyle( fontFamily: "Avenir",),),
              color: Colors.amber,
              textColor: Colors.white,
            ),
          ),
          Spacer(),
        ],
    );
  }
  getOtpFormWidget(context) {
    return Column(
      children: [
        Spacer(),
        TextField(
          controller: otpController,
          decoration: InputDecoration(
            hintText: "Enter OTP",
            hintStyle: TextStyle( fontFamily: "Avenir",),
          ),
        ),
        SizedBox(height: 15,),
        FlatButton(
          onPressed: () async{
            PhoneAuthCredential phoneAuthCredential = PhoneAuthProvider.credential(verificationId: verificationId, smsCode: otpController.text);
            signInWithPhoneAuthCredential(phoneAuthCredential);
          },
          child: Text("Verify", style: TextStyle( fontFamily: "Avenir",),),
          color: Colors.amber,
          textColor: Colors.white,
        ),
        Spacer(),
      ],
    );
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: showLoading ? Center(
          child: CircularProgressIndicator(),
        )
            : currentState == MobileVerificationState.SHOW_MOBILE_FORM_STATE
            ? getMobileFormWidget(context)
            : getOtpFormWidget(context),
        padding: const EdgeInsets.all(16),
      )
    );
  }
}