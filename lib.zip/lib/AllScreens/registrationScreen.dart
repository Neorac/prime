import 'package:Psytric/AllScreens/loginScreen.dart';
import 'package:Psytric/AllScreens/mainScreen.dart';
import 'package:Psytric/AllWidgets/progressDialog.dart';
import 'package:Psytric/main.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class RegistrationScreen extends StatelessWidget
{
  static const String idScreen = "register";

  TextEditingController nameTextEditingController = TextEditingController();
  TextEditingController emailTextEditingController = TextEditingController();
  TextEditingController phoneTextEditingController = TextEditingController();
  TextEditingController passwordTextEditingController = TextEditingController();
  TextEditingController confirmPasswordTextEditingController = TextEditingController();

  final GlobalKey<FormState> _formkey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              SizedBox(height: 65.0,),
              Image(
                image: AssetImage('asset/headerlogo.png'),
                width: 155.0,
                height: 29.0,
                alignment: Alignment.center,
              ),
              SizedBox(height: 10.0,),
              Text(
                "Create your Account",
                style: TextStyle(fontSize: 25.0, fontFamily: "Avenir",),
                textAlign: TextAlign.center,
              ),
              Text(
                "The first step to an amazing experience.",
                style: TextStyle(fontSize: 12.0, fontFamily: "Avenir",),
                textAlign: TextAlign.center,
              ),
              Padding(
                padding: EdgeInsets.all(20.0),
                child: Column(
                  key: _formkey,
                  children: [
                    SizedBox(height: 1.0,),
                    TextFormField(
                      controller: nameTextEditingController,
                      keyboardType: TextInputType.text,
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 18,
                        height: 1.5,
                        color: Colors.black,
                      ),
                      autofocus: true,
                      decoration: InputDecoration(
                        prefixIcon: Icon(Icons.drive_file_rename_outline),
                        labelText: "Full Name",
                        labelStyle: TextStyle(
                          fontFamily: "Avenir",
                          fontSize: 14.0,
                          color: Colors.black,
                        ),
                        hintText: "John Doe",
                        hintStyle: TextStyle(color: Colors.grey[300]),
                        border: InputBorder.none,
                      ),
                    ),
                    SizedBox(height: 1.0,),
                    TextFormField(
                      controller: emailTextEditingController,
                      keyboardType: TextInputType.emailAddress,
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 18,
                        height: 1.5,
                        color: Colors.black,
                      ),
                      autofocus: true,
                      decoration: InputDecoration(
                        prefixIcon: Icon(Icons.email_rounded),
                        labelText: "Email",
                        labelStyle: TextStyle(
                          fontFamily: "Avenir",
                          fontSize: 14.0,
                          color: Colors.black,
                        ),
                        hintText: "user@email.com",
                        hintStyle: TextStyle(color: Colors.grey[300]),
                        border: InputBorder.none,
                      ),
                    ),
                    SizedBox(height: 1.0,),
                    TextFormField(
                      controller: phoneTextEditingController,
                      keyboardType: TextInputType.phone,
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 18,
                        height: 1.5,
                        color: Colors.black,
                      ),
                      autofocus: true,
                      decoration: InputDecoration(
                        prefixIcon: Icon(Icons.smartphone_rounded),
                        labelText: "Phone Number",
                        labelStyle: TextStyle(
                          fontFamily: "Avenir",
                          fontSize: 14.0,
                          color: Colors.black,
                        ),
                        hintText: "08130000068",
                        hintStyle: TextStyle(color: Colors.grey[300]),
                        border: InputBorder.none,
                      ),
                    ),
                    SizedBox(height: 1.0,),
                    TextFormField(
                      controller: passwordTextEditingController,
                      obscureText: true,
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 18,
                        height: 1.5,
                        color: Colors.black,
                      ),
                      autofocus: true,
                      decoration: InputDecoration(
                        prefixIcon: Icon(Icons.lock),
                        labelText: "Password",
                        labelStyle: TextStyle(
                          fontFamily: "Avenir",
                          fontSize: 14.0,
                          color: Colors.black,
                        ),
                        hintText: "p*****rd",
                        hintStyle: TextStyle(color: Colors.grey[300]),
                        border: InputBorder.none,
                      ),
                    ),
                    SizedBox(height: 1.0,),
                    TextFormField(
                      controller: confirmPasswordTextEditingController,
                      obscureText: true,
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 18,
                        height: 1.5,
                        color: Colors.black,
                      ),
                      autofocus: true,
                      decoration: InputDecoration(
                        prefixIcon: Icon(Icons.lock),
                        labelText: "Confirm Password",
                        labelStyle: TextStyle(
                          fontFamily: "Avenir",
                          fontSize: 14.0,
                          color: Colors.black,
                        ),
                        hintText: "p*****rd",
                        hintStyle: TextStyle(color: Colors.grey[300], fontFamily: "Avenir",),
                        border: InputBorder.none,
                      ),
                    ),
                    SizedBox(height: 30.0,),
                    // ignore: deprecated_member_use
                    RaisedButton(
                      color: Colors.amber,
                      textColor: Colors.black,
                      child: Container(
                        height: 50.0,
                        child: Center(
                          child: Text(
                            "Create Account",
                            style: TextStyle(fontSize: 18.0, fontFamily: "Avenir"),
                          ),
                        ),
                      ),
                      shape: new RoundedRectangleBorder(
                        borderRadius: new BorderRadius.circular(24.0),
                      ),
                      onPressed: ()
                      {
                        if(nameTextEditingController.text.length < 4)
                        {
                          displayToastMessage("Name too short!", context);
                        }
                        else if(!emailTextEditingController.text.contains("^[a-zA-Z0-9_-.]+@[a-zA-Z0-9_-.]+.[a-zA-Z]"))
                        {
                          displayToastMessage("Input a Valid Email address!", context);
                        }
                        else if(phoneTextEditingController.text.isEmpty)
                        {
                          displayToastMessage("Input a Valid Phone Number!", context);
                        }
                        else if(passwordTextEditingController.text.length < 9)
                        {
                          displayToastMessage("Password too short!", context);
                        }
                        else if(confirmPasswordTextEditingController.text != passwordTextEditingController.text)
                        {
                          displayToastMessage("Passwords do not match!", context);
                        }
                        else
                        {
                          registerNewUser(context);
                        }
                      },
                    ),
                  ],
                ),
              ),
              GestureDetector( onTap: ()
              {
                Navigator.pushNamedAndRemoveUntil(context, loginScreen.idScreen, (route) => false);
              },
                child: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text:'Already have an account?',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 15,
                          fontFamily: "Avenir",
                          fontWeight: FontWeight.w300,
                        ),
                      ),
                      TextSpan(
                        text:'  Log In',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 15,
                          fontFamily: "Avenir",
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),),
              ),
            ],
          ),
        ),
      ),
    );
  }

  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  void registerNewUser(BuildContext context) async
  {

    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context)
        {
          return ProgressDialog(message: "please wait...",);
        }
    );

    final User firebaseUser = (await _firebaseAuth
        .createUserWithEmailAndPassword(
        email: emailTextEditingController.text,
        password: passwordTextEditingController.text
    ).catchError((errMsg){
      Navigator.pop(context);
      displayToastMessage("Error: " + errMsg.text.toString(), context);
    })).user;

    if(firebaseUser != null) //user created
        {
      //save user info to db
      Map userDataMap = {
        "name": nameTextEditingController.text.trim(),
        "email": emailTextEditingController.text.trim(),
        "phone": phoneTextEditingController.text.trim(),
      };

      userRef.child(firebaseUser.uid).set(userDataMap);
      displayToastMessage("Congratulations, your account has been created successfully!", context);

      Navigator.pushNamedAndRemoveUntil(context, MainScreen.idScreen, (route) => false);
    }
    else
    {
      Navigator.pop(context);
      //error occurred - display error msg
      displayToastMessage("New user account has not been created", context);
    }

  }
}

displayToastMessage(String message, BuildContext context)
{
  Fluttertoast.showToast(msg: "Name too short!");
}