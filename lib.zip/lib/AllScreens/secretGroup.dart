import 'package:Psytric/model/SecretGroupModels.dart';
import 'package:flutter/material.dart';
import 'package:Psytric/AllScreens/CommentsPageScreen.dart';

class SecretGroup extends StatelessWidget {
static const String idScreen = "SecretGroup";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Post(),

    );
  }
}


class AvatarImage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 35,
      height: 35,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        image: DecorationImage(
          fit: BoxFit.contain,
          image: AssetImage("asset/user_icon.png")
        )
      ),
    );
  }
}

class PostTitle extends StatelessWidget {
  get index => null;


  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(10),
      child: Row(
        children: <Widget>[
          AvatarImage(),
          Container(
            padding: EdgeInsets.fromLTRB(13, 0, 0, 0),
            child: Text(group[index].categories.toUpperCase(),
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 19,
                fontFamily: "Avenir",
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class Post extends StatefulWidget {

  @override
  _PostState createState() => _PostState();
}

class _PostState extends State<Post> {
  bool saved = false;

  _saved(){
    setState(() {
      saved = !saved;
    });
  }

  _commentButtonPressed(){
    setState(() {
      Navigator.push(context, MaterialPageRoute(builder: (context) => CommentsChat()));
    });
  }
  @override
  Widget build(BuildContext context) {
    IconButton savedButton = IconButton(
      iconSize: 30,
      splashColor: Colors.transparent,
      icon: Icon(saved ? Icons.bookmark : Icons.bookmark_border_outlined,
      color: saved ? Colors.black : Colors.grey[600],),
      onPressed: () => _saved(),
    );

    IconButton commentButton = IconButton(
      iconSize: 30,
      splashColor: Colors.transparent,
      icon: Icon(Icons.chat,
      color: Colors.grey[600],),
      onPressed: () => _commentButtonPressed(),
    );
    return Container(
      child: Column(
        children: [
          PostTitle(),
          Image.asset("images/1.jpg"),
          ListTile(
            leading: commentButton,
            trailing: savedButton,
          ),
        ],
      ),
    );
  }
}

