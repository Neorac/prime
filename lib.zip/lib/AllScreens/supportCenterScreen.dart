import 'package:flutter/material.dart';
import '../AllScreens/settingsScreen.dart';

class SupportCenterPage extends StatefulWidget {

  static const String idScreen = "SupportCenterPage";

  @override
  _SupportCenterPageState createState() => _SupportCenterPageState();
}
class _SupportCenterPageState extends State<SupportCenterPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("Support Center", style: TextStyle( fontFamily: "Avenir",),),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        leading: IconButton(
          onPressed: () {
            Navigator.pushNamedAndRemoveUntil(context, SettingsPage.idScreen, (route) => false);
          },
          icon: Icon(
            Icons.arrow_back_ios,
            color: Colors.black,
          ),
        ),
      ),
      body: Container(
        padding: EdgeInsets.only(left: 15, top: 25, right: 15,),
        child: ListView(
          children: [
            Container(
              padding: EdgeInsets.only(left: 20, right: 16,),
              height: 25,
              alignment: Alignment.centerLeft,
              child: Text("HELPLINES", style: TextStyle( fontFamily: "Avenir", fontSize: 15, fontWeight: FontWeight.w500),
              ),
            ),
            SizedBox(height: 15.0,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, SupportCenterPage.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Emergency contacts",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 2,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, SupportCenterPage.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("State helplines",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 2,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, SupportCenterPage.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Consult a specialist",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 35.0,),
            Container(
              padding: EdgeInsets.only(left: 20, right: 16,),
              //color: Colors.grey[300],
              height: 25,
              alignment: Alignment.centerLeft,
              child: Text("APP SERVICES", style: TextStyle( fontFamily: "Avenir", fontSize: 15, fontWeight: FontWeight.w500),
              ),
            ),
            SizedBox(height: 15,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, SupportCenterPage.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Therapy chatbot",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 2,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, SupportCenterPage.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Guidelines",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 35.0,),
            Container(
              padding: EdgeInsets.only(left: 20, right: 16,),
              height: 25,
              alignment: Alignment.centerLeft,
              child: Text("INFORMATION", style: TextStyle( fontFamily: "Avenir", fontSize: 15, fontWeight: FontWeight.w500),
              ),
            ),
            SizedBox(height: 15.0,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, SupportCenterPage.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("FAQs",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 2,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, SupportCenterPage.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Support",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 2,),
          ],
        ),
      ),
    );
  }
}