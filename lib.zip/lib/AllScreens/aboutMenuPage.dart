import 'package:flutter/material.dart';
import '../AllScreens/aboutScreen.dart';
import '../AllScreens/editProfileScreen.dart';

class AboutMenuPage extends StatefulWidget {

  static const String idScreen = "AboutMenuPage";

  @override
  _AboutMenuPageState createState() => _AboutMenuPageState();
}

class _AboutMenuPageState extends State<AboutMenuPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        title: Text("About Psytric", style: TextStyle( fontFamily: "Avenir",),),
        leading: IconButton(
          onPressed: () {
            Navigator.pushNamedAndRemoveUntil(context, EditProfileScreen.idScreen, (route) => false);
          },
          icon: Icon(
            Icons.arrow_back_ios,
            color: Colors.black,
          ),
        ),
      ),
      body: Container(
        padding: EdgeInsets.only(left: 15, top: 25, right: 15,),
        child: ListView(
          children: [
             SizedBox(height: 30.0,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, AboutScreen.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("About us",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 2,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, AboutMenuPage.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                  //boxShadow: [BoxShadow(color: Colors.black12, offset: Offset(2.0, 2.0), blurRadius: 1.0, spreadRadius: 1.0,)]
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Privacy policy",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 2,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, AboutMenuPage.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Terms & conditions",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 2,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, AboutMenuPage.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Legal",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 2,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, AboutMenuPage.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Agencies/Organizations",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 2,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, AboutMenuPage.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Personnel",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 15.0,),
          ],
        ),
      ),
    );
  }
}
