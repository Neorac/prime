import '../AllScreens/mainScreen.dart';
import '../AllScreens/loginScreen2.dart';
import '../AllScreens/registrationScreen.dart';
import '../AllWidgets/progressDialog.dart';
import '../main.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import '../AllScreens/forgotScreen.dart';

class loginScreen extends StatelessWidget
{
  static const String idScreen = "login";

  TextEditingController emailTextEditingController = TextEditingController();
  TextEditingController passwordTextEditingController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              SizedBox(height: 65.0,),
              Image(
                image: AssetImage('asset/headerlogo.png'),
                width: 155.0,
                height: 29.0,
                alignment: Alignment.center,
              ),
              SizedBox(height: 10.0,),
              Text(
                "Login to your Account",
                style: TextStyle(fontSize: 25.0, fontFamily: "Avenir"),
                textAlign: TextAlign.center,
              ),
              Text(
                "Welcome back, you’ve been missed!",
                style: TextStyle(fontSize: 12.0, fontFamily: "Avenir",),
                textAlign: TextAlign.center,
              ),
              Padding(
                padding: EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    SizedBox(height: 1.0,),
                    TextFormField(
                      controller: emailTextEditingController,
                      keyboardType: TextInputType.emailAddress,
                      style: TextStyle(
                        fontSize: 18,
                        fontFamily: "Avenir",
                        height: 1.5,
                        color: Colors.black,
                      ),
                      autofocus: true,
                      decoration: InputDecoration(
                        prefixIcon: Icon(Icons.email_rounded),
                        labelText: "Email",
                        labelStyle: TextStyle(
                          fontSize: 14.0,
                          fontFamily: "Avenir",
                          color: Colors.black,
                        ),
                        hintText: "user@email.com",
                        hintStyle: TextStyle(color: Colors.grey[300]),
                        border: InputBorder.none,
                      ),
                    ),
                    SizedBox(height: 15.0,),
                    Padding(padding: EdgeInsets.only(right: 20.0),
                      child: Container(
                        width: double.infinity,
                        child: InkWell(
                          onTap: (){
                            Navigator.pushReplacement(context, MaterialPageRoute(builder: (BuildContext context) => loginScreen2()));
                          },
                          child: Text("Use Phone instead?", style: TextStyle(color: Colors.amber,  fontFamily: "Avenir",),
                            textAlign: TextAlign.right,),
                        ),
                      ),
                    ),
                    SizedBox(height: 1.0,),
                    TextFormField(
                      controller: passwordTextEditingController,
                      obscureText: true,
                      style: TextStyle(
                        fontSize: 18,
                        fontFamily: "Avenir",
                        height: 1.5,
                        color: Colors.black,
                      ),
                      autofocus: true,
                      decoration: InputDecoration(
                        prefixIcon: Icon(Icons.lock),
                        labelText: "Password",
                        labelStyle: TextStyle(
                          fontSize: 14.0,
                          fontFamily: "Avenir",
                          color: Colors.black,
                        ),
                        hintText: "p*****rd",
                        hintStyle: TextStyle(color: Colors.grey[300],  fontFamily: "Avenir",),
                        border: InputBorder.none,
                      ),
                    ),
                    SizedBox(height: 30.0,),
                    Padding(padding: EdgeInsets.only(right: 20.0),
                    child: Container(
                      width: double.infinity,
                        child: InkWell(
                          onTap: (){
                            Navigator.pushReplacement(context, MaterialPageRoute(builder: (BuildContext context) => forgotScreen()));
                          },
                          child: Text("Forgot password?", style: TextStyle(
                            color: Colors.amber,  fontFamily: "Avenir",),
                            textAlign: TextAlign.right,
                          ),
                        ),
                    ),
                    ),
                    SizedBox(height: 30.0,),
                    RaisedButton(
                      color: Colors.amber,
                      textColor: Colors.black,
                      child: Container(
                        height: 50.0,
                        child: Center(
                          child: Text(
                            "Login",
                            style: TextStyle(fontSize: 18.0, fontFamily: "Avenir",),
                          ),
                        ),
                      ),
                      shape: new RoundedRectangleBorder(
                        borderRadius: new BorderRadius.circular(24.0),
                      ),
                      onPressed: ()
                      {
                        if(!emailTextEditingController.text.contains("@"))
                        {
                          displayToastMessage("Input a Valid Email address!", context);
                        }
                        else if(passwordTextEditingController.text.isEmpty)
                        {
                          displayToastMessage("Password required!", context);
                        }
                        else
                        {
                          loginAndAuthenticateUser(context);
                        }
                      },
                    ),
                  ],
                ),
              ),
              Column(
                children: <Widget>[
                  Text('- OR -', style: TextStyle( fontFamily: "Avenir", fontWeight: FontWeight.w500, color: Colors.black),),
                  SizedBox(height: 10,),
                  Text('Sign in with', style: TextStyle( fontFamily: "Avenir", fontWeight: FontWeight.w500, color: Colors.black),),
                ],
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 19.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Container(
                      height: 60,
                      width: 60,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black26,
                            offset: Offset(0, 2),
                            blurRadius: 6,
                          ),
                        ],
                        image: DecorationImage(
                          image: AssetImage('asset/googlelogo1.png'),
                          fit: BoxFit.scaleDown,
                        ),
                      ),
                    ),
                    Container(
                      height: 60,
                      width: 60,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black26,
                            offset: Offset(0, 2),
                            blurRadius: 6,
                          ),
                        ],
                        image: DecorationImage(
                          image: AssetImage('asset/applelogo1.png'),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    Container(
                      height: 60,
                      width: 60,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black26,
                            offset: Offset(0, 2),
                            blurRadius: 6,
                          ),
                        ],
                        image: DecorationImage(
                          image: AssetImage('asset/fblogo1.png'),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              GestureDetector( onTap: ()
              {
                Navigator.pushNamedAndRemoveUntil(context, RegistrationScreen.idScreen, (route) => false);
              },
                child: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text:'Dont\'t have an account?',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 15,
                          fontFamily: "Avenir",
                          fontWeight: FontWeight.w300,
                        ),
                      ),
                      TextSpan(
                        text:'Sign Up',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 15,
                          fontFamily: "Avenir",
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),),
              ),
            ],
          ),
        ),
      ),
    );
  }

  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  void loginAndAuthenticateUser(BuildContext context) async
  {
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context)
        {
          return ProgressDialog(message: "please wait...",);
        }
    );

    final User firebaseUser = (await _firebaseAuth
        .signInWithEmailAndPassword(
        email: emailTextEditingController.text,
        password: passwordTextEditingController.text
    ).catchError((errMsg){
      Navigator.pop(context);
      displayToastMessage("Error:" + errMsg.text.toString(), context);
    })).user;

    if(firebaseUser != null)
    {
      userRef.child(firebaseUser.uid).once().then((DataSnapshot snap){
        if (snap.value != null)
        {
          Navigator.pushNamedAndRemoveUntil(context, MainScreen.idScreen, (route) => false);
          displayToastMessage("Log in successful!", context);
        }
        else
        {
          Navigator.pop(context);
          _firebaseAuth.signOut();
          displayToastMessage("Not an existing account, please sign up!", context);
        }
      });
    }
    else
    {
      Navigator.pop(context);
      displayToastMessage("Error, can't sign you in.", context);
    }
  }
}