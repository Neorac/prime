import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../AllScreens/editProfileScreen.dart';
import '../AllScreens/loginScreen.dart';
import 'aboutScreen.dart';

class EditAvatar extends StatefulWidget {

  static const String idScreen = "EditAvatar";

  TextEditingController unameTextEditingController = TextEditingController();

  @override
  _EditAvatarState createState() => _EditAvatarState();
}

class _EditAvatarState extends State<EditAvatar> {
  get unameTextEditingController => null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          elevation: 0,
          //title: Text("SETTINGS"),
          leading: IconButton(
            onPressed: () {
              Navigator.pushNamedAndRemoveUntil(context, EditProfileScreen.idScreen, (route) => false);
            },
            icon: Icon(
              Icons.arrow_back_ios,
              color: Colors.black,
            ),
          ),
          title: Text('Edit Profile', style: TextStyle( fontFamily: "Avenir",),),
          actions: <Widget>[
            FlatButton(
              textColor: Colors.white,
              onPressed: () async {
                FirebaseAuth.instance.signOut();
                Navigator.pushNamedAndRemoveUntil(
                    context, loginScreen.idScreen, (route) => false);
              },
              child: Text("Log Out",
                style: TextStyle(
                  fontFamily: "Avenir",
                  fontSize: 18,
                  color: Colors.red,
                  fontWeight: FontWeight.w400,
              ),),
            ),
          ],
        ),
        body: ListView(
          children: [
            Container(
              child: Container(
                height: 222,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(0),
                    image: DecorationImage(
                      fit: BoxFit.cover,
                      image: AssetImage("images/5.jpg"),
                    ),
                ),
              ),
            ),
            SizedBox(height: 30.0,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, AboutScreen.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextFormField(
                      controller: unameTextEditingController,
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 18,
                        height: 1.5,
                        color: Colors.black,
                      ),
                      autofocus: true,
                      decoration: InputDecoration(
                        hintText: "eg. future achievements",
                        hintStyle: TextStyle( fontFamily: "Avenir", color: Colors.grey[400]),
                        border: InputBorder.none,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 2,),
          ],
        )
    );
  }
}