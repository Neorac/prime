import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../AllScreens/recoveryRedirect.dart';

class forgotScreen extends StatefulWidget
{
  static const String idScreen = "forgotScreen";

  TextEditingController emailTextEditingController = TextEditingController();
  @override
  State<StatefulWidget> createState(){
    //TODO: implement createState
    return _forgotScreen();
  }
}

class _forgotScreen extends State<forgotScreen>{
  String email = "";

  get firebaseUser => null;
  @override
  Widget build(BuildContext context) {
    //TODO: implement build
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Padding(padding: EdgeInsets.only(top: 150.0, left: 20.0, right: 20.0,),
            child: Column(
              children: <Widget>[
              Text(
              "Forgot your password?",
              style: TextStyle(fontSize: 25.0, fontFamily: "Avenir"),
              textAlign: TextAlign.center,
              ),
            SizedBox(height: 10.0,),
              Text("Enter your email address and we will send you instructions on how to reset your password.",
                style: TextStyle(color: Colors.black, fontSize: 12.0, fontFamily: "Avenir",),
                textAlign: TextAlign.center,
                ),
                SizedBox(height: 10.0,),
                TextFormField(
                  validator: (value){
                    if (value.isEmpty){
                      return "Please enter you email";
                    }else{
                      email=value;
                    }
                    return null;
                  },
                  keyboardType: TextInputType.emailAddress,
                  style: TextStyle(
                    fontSize: 18,
                    fontFamily: "Avenir",
                    height: 1.5,
                    color: Colors.black,
                  ),
                  autofocus: true,
                  decoration: InputDecoration(
                    labelText: "Email",
                    labelStyle: TextStyle(
                      fontSize: 14.0,
                      fontFamily: "Avenir",
                      color: Colors.black,
                    ),
                    hintText: "user@email.com",
                    hintStyle: TextStyle(color: Colors.grey[300]),
                    border: InputBorder.none,
                  ),
                ),
                SizedBox(height: 105.0,),
                RaisedButton(
                  color: Colors.amber,
                  textColor: Colors.black,
                  child: Container(
                    height: 50.0,
                    child: Center(
                      child: Text(
                        "Recover Email",
                        style: TextStyle(fontSize: 18.0, fontFamily: "Avenir"),
                      ),
                    ),
                  ),
                  shape: new RoundedRectangleBorder(
                    borderRadius: new BorderRadius.circular(24.0),
                  ),
                  onPressed: ()
                  {
                    FirebaseAuth.instance.sendPasswordResetEmail(email: email);

                    Navigator.pushNamedAndRemoveUntil(context, recoveryRedirect.idScreen, (route) => false);
                  },
                ),
              ],
            ),
        ),
      ),
    );
  }
}