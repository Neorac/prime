import 'package:flutter/material.dart';
import 'editProfileScreen.dart';

class AboutScreen extends StatefulWidget
{
  static const String idScreen = "about";
  @override
  _MyAboutScreenState createState() => _MyAboutScreenState();
}

class _MyAboutScreenState extends State<AboutScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          elevation: 0,
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back_ios,
              color: Colors.black,
            ),
            onPressed: () {
              Navigator.pushNamedAndRemoveUntil(context, EditProfileScreen.idScreen, (route) => false);
            },
          ),
        ),
        backgroundColor: Colors.white,
        body: ListView(
          children: <Widget>[
            Container(
              height: 220,
              child: Center(
                child: Image.asset('asset/headerlogo.png'),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 30, left: 24, right: 24),
              child: Column(
                children: <Widget>[
                  Text(
                    'PSYTRIC Health App',
                    style: TextStyle(
                        fontSize: 25,
                        fontFamily: 'Avenir'),
                  ),
                  SizedBox(height: 30),
                  Text(
                    'This app has been developed by Joseph Chidi, '
                        'Co-founder of PSYTRIC Health Services. Psytric is a suicide control application being developed that helps mentally unstable and suicidal '
                        'individuals live longer by giving them reasons to stay alive. The app aims to provide reassurance, information, conversation, relatable quotes, '
                        'recommendations and more to assist individuals dealing with diverse mental health struggles. '
                        'This app offers the best insights and studies into mental health and the best practices, and that\'s why 10B+ people already use this app',
                    style: TextStyle(fontFamily: "Avenir"),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            SizedBox(height: 40),
          ],
        )
    );
  }
}