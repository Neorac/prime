import 'package:flutter/material.dart';
import '../AllScreens/loginScreen.dart';

class recoveryRedirect extends StatefulWidget
{
  static const String idScreen = "recoveryRedirect";
  @override
  State<StatefulWidget> createState(){
    //TODO: implement createState
    return _recoveryRedirect();
  }
}

class _recoveryRedirect extends State<recoveryRedirect>{
  @override
  Widget build(BuildContext context) {
    //TODO: implement build
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Padding(padding: EdgeInsets.only(
          top: 150.0, left: 20.0, right: 20.0,),
          child: Column(
            children: <Widget>[
              Image(
                image: AssetImage('asset/sent.png'),
                width: 150.0,
                height: 150.0,
                alignment: Alignment.center,
              ),
              Text(
                "Check your email",
                style: TextStyle(fontSize: 25.0, fontFamily: "Avenir"),
                textAlign: TextAlign.center,
              ),
              Text("We've sent you instructions on how to reset the password (also check the Spam folder).",
                style: TextStyle(color: Colors.black, fontSize: 12.0, fontFamily: "Avenir",),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 175.0,),
              RaisedButton(
                color: Colors.amber,
                textColor: Colors.white,
                child: Container(
                  height: 50.0,
                  child: Center(
                    child: Text(
                      "Return to Login",
                      style: TextStyle(fontSize: 18.0, fontFamily: "Avenir"),
                    ),
                  ),
                ),
                shape: new RoundedRectangleBorder(
                  borderRadius: new BorderRadius.circular(24.0),
                ),
                onPressed: ()
                {
                  Navigator.pushNamedAndRemoveUntil(context, loginScreen.idScreen, (route) => true);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}