import 'package:flutter/material.dart';
import '../AllWidgets/loading.dart';
import '../AllScreens/settingsScreen.dart';
import '../model/bL.dart';
import '../services/database_services.dart';
import 'editProfileScreen.dart';

class BuckList extends StatefulWidget {

  static const String idScreen = "BucketList";
  @override
  _BuckListState createState() => _BuckListState();
}
class _BuckListState extends State<BuckList> {

  bool isComplete = false;
  TextEditingController bucketTitleController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios,
            color: Colors.black,
          ),
          onPressed: () {
            Navigator.pushNamedAndRemoveUntil(
                context, EditProfileScreen.idScreen, (route) => false);
          },
        ),
        title: Text('Your Bucket List', style: TextStyle( fontFamily: "Avenir",),),
        actions: [
          IconButton(
            icon: Icon(
              Icons.notifications,
              color: Colors.black,
            ),
            onPressed: () {
              Navigator.pushNamedAndRemoveUntil(
                  context, SettingsPage.idScreen, (route) => false);
            },
          ),
        ],
      ),
      body: SafeArea(
        child: StreamBuilder<List<Bucket>>(
            stream: DatabaseService().listBuckets(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return Loading();
              }
              List<Bucket> buckets = snapshot.data;
              return Padding(
                padding: EdgeInsets.all(25),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(height: 10),
                    Expanded(
                      child: ListView.separated(
                        separatorBuilder: (context, index) => Divider(
                          color: Colors.grey[800],
                        ),
                        shrinkWrap: true,
                        itemCount: buckets.length,
                        itemBuilder: (context, index) {
                          return Dismissible(
                            key: Key(buckets[index].title),
                            background: Container(
                              padding: EdgeInsets.only(left: 20),
                              alignment: Alignment.centerRight,
                              child: Icon(Icons.delete),
                              color: Colors.red,
                            ),
                            onDismissed: (direction)  async {
                              await DatabaseService()
                                  .removeBucket(buckets[index].uid);
                            },
                            child: ListTile(
                              onTap: () {
                                DatabaseService().completeTask(buckets[index].uid);
                              },
                              leading: Container(
                                padding: EdgeInsets.all(2),
                                height: 30,
                                width: 30,
                                decoration: BoxDecoration(
                                  color: Theme.of(context).primaryColor,
                                  shape: BoxShape.circle,
                                ),
                                child: buckets[index].isComplete
                                    ? Icon(
                                        Icons.check,
                                        color: Colors.white,
                                      )
                                    : Container(),
                              ),
                              title: Text(
                                buckets[index].title,
                                style: TextStyle(
                                  fontFamily: "Avenir",
                                  fontSize: 20,
                                  color: Colors.black,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    )
                  ],
                ),
              );
            }),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10)
        ),
        backgroundColor: Theme.of(context).primaryColor,
        onPressed: () {
          showDialog(
            builder: (context) => SimpleDialog(
              contentPadding: EdgeInsets.symmetric(
                horizontal: 25,
                vertical: 20,
              ),
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              title: Row(
                children: [
                  Text(
                    "Add to list",
                    style: TextStyle(
                      fontFamily: "Avenir",
                      fontSize: 20,
                      color: Colors.black54,
                    ),
                  ),
                  Spacer(),
                  IconButton(
                    icon: Icon(
                      Icons.cancel,
                      color: Colors.grey,
                      size: 30,
                    ),
                    onPressed: () => Navigator.pop(context),
                  )
                ],
              ),
              children: [
                Divider(),
                TextFormField(
                  controller: bucketTitleController,
                  style: TextStyle(
                    fontFamily: "Avenir",
                    fontSize: 18,
                    height: 1.5,
                    color: Colors.black,
                  ),
                  autofocus: true,
                  decoration: InputDecoration(
                    hintText: "eg. future achievements",
                    hintStyle: TextStyle( fontFamily: "Avenir", color: Colors.grey[400]),
                    border: InputBorder.none,
                  ),
                ),
                SizedBox(height: 20),
                SizedBox(
                  width: width,
                  height: 50,
                  child: FlatButton(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text("Add", style: TextStyle( fontFamily: "Avenir",),),
                    color: Theme.of(context).primaryColor,
                    textColor: Colors.white,
                    onPressed: () async {
                      if (bucketTitleController.text.isNotEmpty) {
                        await DatabaseService()
                            .createNewBucket(bucketTitleController.text.trim());
                        Navigator.pop(context);
                      }
                    },
                  ),
                )
              ],
            ), context: context,
          );
        },
      ),
    );
  }
}