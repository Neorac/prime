import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import '../AllScreens/aboutMenuPage.dart';
import '../AllScreens/bucketList.dart';
import '../AllScreens/setAvatarPage.dart';
import '../AllScreens/settingsScreen.dart';
import 'EvaluationsScreen.dart';
import 'mainScreen.dart';

class EditProfileScreen extends StatefulWidget{

  static const String idScreen = "EditProfileScreen";

  @override
  _EditProfileScreenState createState() => _EditProfileScreenState();
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      //title: "PROFILE",
      home: EditProfileScreen(),
    );
  }
}
class _EditProfileScreenState extends State<EditProfileScreen> {

  @override
  Widget build(BuildContext context) {

    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
          centerTitle: true,
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_ios,
            color: Colors.black,
          ),
          onPressed: () {
            Navigator.pushNamedAndRemoveUntil(
                context, MainScreen.idScreen, (route) => false);
          },
        ),
        title: Text('Personalize', style: TextStyle( fontFamily: "Avenir",),),
        // actions: [
        //   IconButton(
        //     icon: Icon(
        //       Icons.settings,
        //       color: Colors.black,
        //     ),
        //     onPressed: () {
        //       Navigator.pushNamedAndRemoveUntil(
        //           context, SettingsPage.idScreen, (route) => false);
        //     },
        //   ),
        // ],
      ),
      body: Container(
        padding: EdgeInsets.only(left: 15, right:  15),
        child: ListView(
          children: [
            SizedBox(height:  15,),
            Center(
              child: Container(
                height: 222,
                alignment: Alignment.center,
                padding: EdgeInsets.only(left: 10, right: 10, top: 20),
                decoration: BoxDecoration(
                  //color: Colors.grey[300],
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    stops: [0.1, 0.4, 0.7, 0.9],
                    colors: [
                      Colors.black54,
                      Colors.black26,
                      Colors.grey[500],
                      Colors.grey[400],
                    ],
                  ),
                  borderRadius: BorderRadius.circular(10),
                  //boxShadow: [BoxShadow(color: Colors.black12, offset: Offset(2.0, 2.0), blurRadius: 1.0, spreadRadius: 1.0,)]
                ),
                child: Column(
                  children: [
                    Stack(
                      children: [
                        Container(
                          width: 150,
                          height: 150,
                          decoration: BoxDecoration(
                            border: Border.all(
                              width: 3,
                              color: Theme.of(context).scaffoldBackgroundColor
                            ),
                            boxShadow: [
                              BoxShadow(
                                  spreadRadius: 1, blurRadius: 8,
                                  color: Colors.black.withOpacity(0.1),
                                  offset: Offset(0,10)
                              ),
                            ],
                            shape: BoxShape.circle,
                            image: DecorationImage(
                              fit: BoxFit.cover,
                              image: AssetImage("asset/user_icon.png"),
                            )
                          ),
                        ),
                        Positioned(
                            bottom: 0,
                            right: 0,
                            child: Container(
                              height: 40,
                              width: 40,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  width: 2,
                                  color: Theme.of(context).scaffoldBackgroundColor,
                                ),
                                color: Colors.black87,
                              ),
                              child: Center(
                                child: IconButton(
                                  icon: Icon(
                                    Icons.edit,
                                    color: Colors.white,
                                  ),
                                  onPressed: () {
                                    Navigator.pushNamedAndRemoveUntil(context,  EditAvatar.idScreen, (route) => false);
                                  },
                                ),
                              ),
                            ),
                        ),
                      ],
                    ),
                    SizedBox(height: 5),
                    Text("Edit Profile",
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontFamily: "Avenir",
                          fontSize: 20,
                          fontWeight: FontWeight.w400,
                          color: Colors.white
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 25,
            ),
            SizedBox(height: 15,),
            SizedBox(height: 30.0,),
            Container(
              height: 55,
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.only(left: 20, right: 16,),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(6),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Report for a Doctor",
                    style: TextStyle(
                      fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                    ),
                  ),
                  Icon(
                    Icons.arrow_forward_ios,
                    size: 12,
                    color: Colors.black,
                  ),
                ],
              ),
            ),
            SizedBox(height: 2,),
            Container(
              height: 55,
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.only(left: 20, right: 16,),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(6),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Monthly Statistics",
                    style: TextStyle(
                      fontFamily: "Avenir",
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Icon(
                    Icons.arrow_forward_ios,
                    size: 12,
                    color: Colors.black,
                  ),
                ],
              ),
            ),
            SizedBox(height: 35.0,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, EvaluationsScreen.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Evaluations",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 2,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, BuckList.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Medical History",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 2,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, BuckList.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Bucket List",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),


            SizedBox(height: 2,),

            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, SettingsPage.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Settings",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 2,),
            Container(
              height: 55,
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.only(left: 20, right: 16,),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(6),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Notifications",
                    style: TextStyle(
                      fontFamily: "Avenir",
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Icon(
                    Icons.arrow_forward_ios,
                    size: 12,
                    color: Colors.black,
                  ),
                ],
              ),
            ),
            SizedBox(height: 2,),
            Container(
              height: 55,
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.only(left: 20, right: 16,),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(6),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Emergency Settings",
                    style: TextStyle(
                      fontFamily: "Avenir",
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Icon(
                    Icons.arrow_forward_ios,
                    size: 12,
                    color: Colors.black,
                  ),
                ],
              ),
            ),
            SizedBox(height: 2,),
            GestureDetector( onTap: () {
              Navigator.pushNamedAndRemoveUntil(context, AboutMenuPage.idScreen, (route) => false);
            },
              child: Container(
                height: 55,
                alignment: Alignment.centerLeft,
                padding: EdgeInsets.only(left: 20, right: 16,),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("About Psytric",
                      style: TextStyle(
                        fontFamily: "Avenir",
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 12,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 30,),
            Container(
              child: Center(
                child: Image.asset('asset/headerlogo.png'),
              ),
            ),
            SizedBox(height: 25.0,),
            Text("This app does not replace/substitute seeking necessary professional help.",
              style: TextStyle(
                fontFamily: "Avenir",
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
            SizedBox(height: 45.0,),
          ],
        ),
      ),
    );
  }
}




//
// class BottomSheet{
//
//   showBottomSheet(context){
//
//     var screenHeight = MediaQuery.of(context).size.height *0.5;
//     var screenWidth = MediaQuery.of(context).size.width *0.7;
//
//     return showModalBottomSheet(
//         backgroundColor: Colors.transparent,
//         context: context,
//         builder: (BuildContext context){
//           return Container(
//             height: screenHeight,
//             width: screenWidth,
//             decoration: BoxDecoration(
//               color: Colors.grey[100],
//               borderRadius: BorderRadius.only(
//                 topLeft: Radius.circular(35),
//                 topRight: Radius.circular(35),
//               ),
//             ),
//             child: Padding(
//               padding: const EdgeInsets.all(20.0),
//               child: ListView(
//                 children: [
//                   // TextField(
//                   //   decoration: InputDecoration(
//                   //       border: OutlineInputBorder(
//                   //         borderRadius: BorderRadius.circular(15.0),
//                   //       ),
//                   //       filled: true,
//                   //       hintStyle: TextStyle(color: Colors.grey[400]),
//                   //       hintText: "Search",
//                   //       fillColor: Colors.white70),
//                   // ),
//
//
//
//                   SizedBox(height: 30.0,),
//
//                   GestureDetector( onTap: () {
//                     Navigator.pushNamedAndRemoveUntil(context, AboutScreen.idScreen, (route) => false);
//                   },
//                     child: Container(
//                       child: Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           Text(
//                             "About us",
//                             style: TextStyle(
//                                 fontSize: 15,
//                                 fontWeight: FontWeight.w600,
//                                 color: Colors.grey
//                             ),
//                           ),
//                           Icon(
//                             Icons.arrow_forward_ios,
//                             size: 12,
//                             color: Colors.grey,
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//
//                   SizedBox(height: 15.0,),
//
//                   DividerWidget(),
//
//                   SizedBox(height: 15.0,),
//
//                   GestureDetector( onTap: () {
//                     Navigator.pushNamedAndRemoveUntil(context, SupportCenterPage.idScreen, (route) => false);
//                   },
//                     child: Container(
//                       child: Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           Text(
//                             "Privacy policy",
//                             style: TextStyle(
//                                 fontSize: 15,
//                                 fontWeight: FontWeight.w600,
//                                 color: Colors.grey
//                             ),
//                           ),
//                           Icon(
//                             Icons.arrow_forward_ios,
//                             size: 12,
//                             color: Colors.grey,
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//
//                   SizedBox(height: 15.0,),
//
//                   DividerWidget(),
//
//                   SizedBox(height: 15.0,),
//
//                   GestureDetector( onTap: () {
//                     Navigator.pushNamedAndRemoveUntil(context, SupportCenterPage.idScreen, (route) => false);
//                   },
//                     child: Container(
//                       child: Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           Text(
//                             "Terms & conditions",
//                             style: TextStyle(
//                                 fontSize: 15,
//                                 fontWeight: FontWeight.w600,
//                                 color: Colors.grey
//                             ),
//                           ),
//                           Icon(
//                             Icons.arrow_forward_ios,
//                             size: 12,
//                             color: Colors.grey,
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//
//                   SizedBox(height: 15.0,),
//
//                   DividerWidget(),
//
//                   SizedBox(height: 15.0,),
//
//                   GestureDetector( onTap: () {
//                     Navigator.pushNamedAndRemoveUntil(context, SupportCenterPage.idScreen, (route) => false);
//                   },
//                     child: Container(
//                       child: Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           Text(
//                             "Legal",
//                             style: TextStyle(
//                                 fontSize: 15,
//                                 fontWeight: FontWeight.w600,
//                                 color: Colors.grey
//                             ),
//                           ),
//                           Icon(
//                             Icons.arrow_forward_ios,
//                             size: 12,
//                             color: Colors.grey,
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//
//                   SizedBox(height: 15.0,),
//
//                   DividerWidget(),
//
//                   SizedBox(height: 15.0,),
//
//                   GestureDetector( onTap: () {
//                     Navigator.pushNamedAndRemoveUntil(context, SupportCenterPage.idScreen, (route) => false);
//                   },
//                     child: Container(
//                       child: Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           Text(
//                             "Agencies/Organizations",
//                             style: TextStyle(
//                                 fontSize: 15,
//                                 fontWeight: FontWeight.w600,
//                                 color: Colors.grey
//                             ),
//                           ),
//                           Icon(
//                             Icons.arrow_forward_ios,
//                             size: 12,
//                             color: Colors.grey,
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//
//                   SizedBox(height: 15.0,),
//
//                   DividerWidget(),
//
//                   SizedBox(height: 15.0,),
//
//                   GestureDetector( onTap: () {
//                     Navigator.pushNamedAndRemoveUntil(context, SupportCenterPage.idScreen, (route) => false);
//                   },
//                     child: Container(
//                       child: Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           Text(
//                             "Personnel",
//                             style: TextStyle(
//                                 fontSize: 15,
//                                 fontWeight: FontWeight.w600,
//                                 color: Colors.grey
//                             ),
//                           ),
//                           Icon(
//                             Icons.arrow_forward_ios,
//                             size: 12,
//                             color: Colors.grey,
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//
//                   SizedBox(height: 15.0,),
//
//                   DividerWidget(),
//
//
//
//                 ],
//               ),
//             ),
//
//           );
//         }
//     );
//   }
// }
//
//
//
//
//
//
// class BottomSheetPage{
//
//   showBottomSheet(context){
//
//     var screenHeight = MediaQuery.of(context).size.height *1;
//     var screenWidth = MediaQuery.of(context).size.width *1;
//
//     return showModalBottomSheet(
//         context: context,
//         builder: (BuildContext context){
//           return Container(
//             height: screenHeight,
//             width: screenWidth,
//           );
//         }
//     );
//   }
// }