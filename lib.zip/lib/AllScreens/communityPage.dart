import 'package:Psytric/AllScreens/editProfileScreen.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../AllWidgets/HeaderNav.dart';
import 'CommentsPageScreen.dart';

class CommunityPage extends StatefulWidget {

  static const String idScreen = "CommunityPage";

  @override
  _CommunityPageState createState() => _CommunityPageState();
}

class _CommunityPageState extends State<CommunityPage> {

  int currentTab = 0;
  final List<Widget> screens = [
    //BucketListPage(),
    //EditProfileScreen(),

  ];

  final PageStorageBucket bucket = PageStorageBucket();
  //Widget currentScreen = BucketListPage();

  List<bool> isSelected = [true, false, false, false];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        bottom: PreferredSize(
        child: Container(
          color: Colors.white,
          height: 55,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              HeaderNav(title: 'New', screenPage: EditProfileScreen(),),
              HeaderNav(title: 'Saved',),
              HeaderNav(title: 'Following',),
              HeaderNav(title: 'Popular',),
            ],
          ),
        ),
        preferredSize: Size.fromHeight(0),
      ),),
      body: Scaffold(
    body: Post(),

      )
    );
  }
}


class AvatarImage extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 35,
      height: 35,
      decoration: BoxDecoration(
          shape: BoxShape.circle,
          image: DecorationImage(
              fit: BoxFit.contain,
              image: AssetImage("asset/user_icon.png")
          )
      ),
    );
  }
}

class PostTitle extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(10),
      child: Row(
        children: <Widget>[
          AvatarImage(),
          Container(
            padding: EdgeInsets.fromLTRB(13, 0, 0, 0),
            child: Text("title",
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 19,
                fontFamily: "Avenir",
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class Post extends StatefulWidget {

  @override
  _PostState createState() => _PostState();
}

class _PostState extends State<Post> {
  bool saved = false;

  _saved(){
    setState(() {
      saved = !saved;
    });
  }

  _commentButtonPressed(){
    setState(() {
      Navigator.push(context, MaterialPageRoute(builder: (context) => CommentsChat()));
    });
  }
  @override
  Widget build(BuildContext context) {
    IconButton savedButton = IconButton(
      iconSize: 30,
      splashColor: Colors.transparent,
      icon: Icon(saved ? Icons.bookmark : Icons.bookmark_border_outlined,
        color: saved ? Colors.black : Colors.grey[600],),
      onPressed: () => _saved(),
    );

    IconButton commentButton = IconButton(
      iconSize: 30,
      splashColor: Colors.transparent,
      icon: Icon(FontAwesomeIcons.comments,
        color: Colors.grey[600],),
      onPressed: () => _commentButtonPressed(),
    );
    return Container(
      child: Column(
        children: [
          PostTitle(),
          Image.asset("asset/warning-signs.jpg"),
          ListTile(
            leading: commentButton,
            trailing: savedButton,
          ),
        ],
      ),
    );
  }
}

