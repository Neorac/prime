import 'package:Psytric/AllScreens/secretGroup.dart';
import 'package:flutter/material.dart';

import 'mainScreen.dart';

class CommentsChat extends StatefulWidget {
  static const String idScreen = "CommentsChat";

  @override
  _CommentsChatState createState() => new _CommentsChatState();
}

class _CommentsChatState extends State<CommentsChat> {

  final fieldText = TextEditingController();

  void clearText() {
    fieldText.clear();
  }

  List<String> _comments = [];

  void _addComments(String val){
    setState(() {
      _comments.add(val);
    });
  }

  Widget _buildCommentsList(){
    return ListView.builder(
        itemBuilder: (context, index){
          if(index < _comments.length) {
            return _buildCommentsItem(_comments[index]);
          }
        }
        );
  }

  Widget _buildCommentsItem(String comment){
    return ListTile(title: Text(comment));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
        icon: Icon(
        Icons.arrow_back_ios,
        color: Colors.black,
      ),
      onPressed: () {
        Navigator.pushNamedAndRemoveUntil(
            context, MainScreen.idScreen,  (route) => false);
      },
    ),

      ),
      body: Column(
        children: <Widget>[Expanded(child: _buildCommentsList()),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: //Row(
            //children: [
              TextField(
                onSubmitted: (String submittedStr){
                  _addComments(submittedStr);
                },
                decoration: InputDecoration(
                  suffixIcon: Icon(Icons.send, color: Colors.amber,),
                  contentPadding: const EdgeInsets.all(12),
                  hintText: "Share your story anonymously..."
                ),
              ),
              // IconButton(onPressed: clearText,
              //     icon: Icon(
              //       Icons.send,
              //       color: Colors.amber,
              //     ),
              // ),
            //],
          //),
        )
        ],
      ),
    );
  }
}
