import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../AllScreens/HomeFeeder.dart';
import '../AllScreens/topicsPage.dart';
import '../AllScreens/editProfileScreen.dart';
import 'EvaluationsScreen.dart';
import 'communityPage.dart';

class MainScreen extends StatefulWidget {

  static const String idScreen = "MainScreen";

  @override
  _MainScreenState createState() => _MainScreenState();
}
class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 1;
  List<Widget> screens = [
    EvaluationsScreen(),
    HomeFeeder(),
    CommunityPage(),
  ];

  final PageStorageBucket bucket = PageStorageBucket();
  Widget currentScreen = HomeFeeder();

  void _onItemTap(int index){
    setState(() {
      _selectedIndex = index;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        //centerTitle: true,
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        title: Image.asset("asset/headerlogo.png", scale: 1.0, width: 170, height: 130,),
        // leading: ConstrainedBox(
        //   constraints: BoxConstraints(
        //     minWidth: 44,
        //     minHeight: 44,
        //     maxWidth: 64,
        //     maxHeight: 64,
        //   ),
        //   child: Image.asset("asset/headerlogo.png", scale: 1.0,),),
        // leading: IconButton(
        //   icon: Icon(
        //     Icons.person,
        //     color: Colors.black,
        //   ),
        //   onPressed: () {
        //     Navigator.pushNamedAndRemoveUntil(
        //         context, EditProfileScreen.idScreen, (route) => false);
        //   },
        // ),
        actions: [
          IconButton(
            icon: Icon(
              FontAwesomeIcons.commentDots,
              color: Colors.black,
              size: 19,
            ),
            onPressed: () {
              Navigator.pushNamedAndRemoveUntil(
                  context, TopicsPage.idScreen, (route) => false);
            },
          ),
    IconButton(
      icon: Icon(
        FontAwesomeIcons.user,
        color: Colors.black,
        size: 19,
      ),
      onPressed: () {
        Navigator.pushNamedAndRemoveUntil(
            context, EditProfileScreen.idScreen, (route) => false);
      },
    ),
        ],
      ),
      body: PageStorage(
        child: screens.elementAt(_selectedIndex),
        bucket: bucket,
      ),
      bottomNavigationBar: BottomNavigationBar(
          items: [
            BottomNavigationBarItem(
                icon: Icon(FontAwesomeIcons.centercode, size: 20,),
                label: 'Self Evaluation',
            ),
            BottomNavigationBarItem(
                icon: Icon(FontAwesomeIcons.stream, size: 20,),
                label: 'Recent Feed',
            ),
            BottomNavigationBarItem(
                icon: Icon(FontAwesomeIcons.mask, size: 20,),
                label: 'Secret Group',
            ),
          ],
          currentIndex: _selectedIndex,
          onTap: _onItemTap,
        ),
    );
  }
}