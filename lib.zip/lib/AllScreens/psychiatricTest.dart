import 'package:flutter/material.dart';

class PsychiatricTest extends StatefulWidget {

  static const String idScreen = "PsychiatricTest";
  @override
  _PsychiatricTestState createState() => _PsychiatricTestState();
}

class _PsychiatricTestState extends State<PsychiatricTest> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0,
        leading: IconButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          icon: Icon(
            Icons.arrow_back_ios,
            color: Colors.black,
          ),
        ),
      ),
      body: Container(
        padding: EdgeInsets.only(left: 16, top: 25, right: 16,),
        alignment: Alignment.topCenter,
         child: Text(
           "Take a quick test",
           style: TextStyle(
             fontFamily: "Avenir",
             fontSize: 30,
             fontWeight: FontWeight.w500,
           ),
         ),
      ),
    );
  }
}