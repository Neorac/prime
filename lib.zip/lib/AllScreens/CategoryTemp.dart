import 'package:flutter/material.dart';
import '../AllWidgets/CategoryGrid.dart';

class CategoryTemp extends StatelessWidget {

  static const String idScreen = "CategoryTemp";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: GridView.count(
              padding: EdgeInsets.all(20),
              crossAxisCount: 2,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: ((MediaQuery.of(context).size.width/2)/300),
              children: [
                CategoryGrid(imgSrc: 'images/1.jpg', title: 'Test Mode',),
                CategoryGrid(imgSrc: 'images/2.jpg', title: 'Test Mode',),
                CategoryGrid(imgSrc: 'images/3.jpeg', title: 'Test Mode',),
                CategoryGrid(imgSrc: 'images/4.jpg', title: 'Test Mode',),
                CategoryGrid(imgSrc: 'images/5.jpg', title: 'Test Mode',),
                CategoryGrid(imgSrc: 'images/1.jpg', title: 'Test Mode',),
                CategoryGrid(imgSrc: 'images/2.jpg', title: 'Test Mode',),
                CategoryGrid(imgSrc: 'images/3.jpeg', title: 'Test Mode',),
                CategoryGrid(imgSrc: 'images/4.jpg', title: 'Test Mode',),
              ],
            ),
          ),
        ],),
    );
  }
}