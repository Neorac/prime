import 'package:flutter/material.dart';

class InsightsYou extends StatelessWidget {
  final String imgSrc;
  final String title;
  final String caption;

  InsightsYou({this.imgSrc, this.title, this.caption,});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), color: Colors.grey[300],),
          margin: EdgeInsets.only(left: 20),
          width: 200,
          height: 250,
          child: ClipRRect(
              borderRadius: BorderRadius.circular(10.0),
              child: Image.asset(this.imgSrc, fit: BoxFit.cover,)),
        ),
        Positioned(
          bottom: 5,
          right: 5,
          child: Container(
            width: 150,
            height: 90,
            color: Colors.transparent,
            padding: EdgeInsets.only(left: 10),
            child: Column(children: [
              Text(this.title, style: TextStyle( fontFamily: "Avenir", fontSize: 17, fontWeight: FontWeight.w400, color: Colors.white,),),
              Text(this.caption, style: TextStyle( fontFamily: "Avenir", fontWeight: FontWeight.w200, fontSize: 10, color: Colors.grey[100]),)
            ],),
          ),
        )
      ],
    );
  }
}