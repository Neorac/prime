import 'package:flutter/material.dart';
import '../AllScreens/loginScreen.dart';
import '../AllScreens/mainScreen.dart';

enum AuthStatus {
  notLoggedIn,
  loggedIn,
}

class OurRoot extends StatefulWidget{

  static const String idScreen = "ourRoot";

  @override
  _OurRootState createState() => _OurRootState();
}

class _OurRootState extends State<OurRoot>{
  AuthStatus _authStatus = AuthStatus.notLoggedIn;

  @override
  void didChangeDependecies() async{
    //TODO: implement didChangeDependecies
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    Widget retVal;

    switch (_authStatus){
      case AuthStatus.notLoggedIn:
        retVal = loginScreen.idScreen as Widget;
        break;
        case AuthStatus.loggedIn:
          retVal = MainScreen.idScreen as Widget;
          break;
      default:
    }
    return retVal;
  }
}