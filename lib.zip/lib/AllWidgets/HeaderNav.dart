import 'package:flutter/material.dart';

class HeaderNav extends StatelessWidget {

  final String title;
  final Widget screenPage;
  final IconData icon;


  HeaderNav({this.title, this.icon, this.screenPage});


  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        margin: EdgeInsets.only(left: 2,),
        width: 100,
        height: 10,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), color: Colors.grey[300],),
        child: Column(
          children: [
            Icon(
              this.icon,
              color: Colors.black,
              size: 15,
            ),
            Text(
              this.title,
              style: TextStyle(
                fontFamily: "Avenir",
                color: Colors.black,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}