import 'package:flutter/material.dart';

class CategoryGrid extends StatelessWidget {

  final String imgSrc;
  final String title;

  CategoryGrid({this.title, this.imgSrc});


  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        ClipRRect(
            borderRadius: BorderRadius.circular(10.0),
            child: Image.asset(this.imgSrc, fit: BoxFit.cover,)
        ),
        Positioned(
          bottom: 0,
          left: 0,
          child: Container(
            width: MediaQuery.of(context).size.width/2,
            padding: EdgeInsets.all(15),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.grey[900].withOpacity(0.15),
                  Colors.grey[900],
                ],
              ),
            ),
            child: Text(
              this.title,
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w700
              ),
            ),
          ),
        ),
      ],
    );
  }
}