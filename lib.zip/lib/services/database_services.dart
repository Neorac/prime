import 'package:cloud_firestore/cloud_firestore.dart';
import '../model/bL.dart';

class DatabaseService {
  CollectionReference bucketsCollection =
      FirebaseFirestore.instance.collection("Buckets");

  Future createNewBucket(String title) async {
    return await bucketsCollection.add({
      "title": title,
      "isComplete": false,
    });
  }

  Future completeTask(uid) async {
    await bucketsCollection.doc(uid).update({"isComplete": true});
  }
  Future removeBucket(uid) async {
    await bucketsCollection.doc(uid).delete();
  }

  List<Bucket> bucketFromFirestore(QuerySnapshot snapshot) {
    if (snapshot != null) {
      return snapshot.docs.map((e) {
        return Bucket(
          isComplete: e["isComplete"],
          title: e["title"],
          uid: e.id,
        );
      }).toList();
    } else {
      return null;
    }
  }
  Stream<List<Bucket>> listBuckets() {
    return bucketsCollection.snapshots().map(bucketFromFirestore);
  }
}