import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../AllScreens/HomeFeeder.dart';
import '../AllScreens/forgotScreen.dart';
import '../AllScreens/loginScreen.dart';
import '../AllScreens/registrationScreen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import '../AllScreens/mainScreen.dart';
import '../AllScreens/recoveryRedirect.dart';
import '../AllScreens/aboutScreen.dart';
import '../AllScreens/editProfileScreen.dart';
import '../AllScreens/topicsPage.dart';
import '../AllWidgets/rootState.dart';
import 'package:provider/provider.dart';
import '../AllScreens/phoneVerify.dart';
import 'AllScreens/EvaluationsScreen.dart';
import 'AllScreens/aboutMenuPage.dart';
import 'AllScreens/otherScreen.dart';
import 'AllWidgets/loading.dart';
import 'AllScreens/loginInfoScreen.dart';
import 'AllScreens/onboardingScreen.dart';
import 'AllScreens/psychiatricTest.dart';
import 'AllScreens/setAvatarPage.dart';
import 'AllScreens/settingsScreen.dart';
import 'AllScreens/supportCenterScreen.dart';
import 'AllScreens/therapyPage.dart';
import '../AllScreens/bucketList.dart';
import '../AllScreens/secretGroup.dart';

void main() async
{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  runApp(MyApp());
}
DatabaseReference userRef = FirebaseDatabase.instance.reference().child("users");

class MyApp extends StatelessWidget {

  DateTime timeBackPressed = DateTime.now();
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
        create: (BuildContext context) {
        },
        child: MaterialApp(
          title: 'PSYTRIC',
          theme: ThemeData(
            primarySwatch: Colors.amber,
            visualDensity: VisualDensity.adaptivePlatformDensity,
            //scaffoldBackgroundColor: Palette.scaffold,
          ),
          initialRoute: MainScreen.idScreen,
          //initialRoute: FirebaseAuth.instance.currentUser == null ? loginScreen.idScreen : MainScreen.idScreen,
          routes:
          {
            RegistrationScreen.idScreen: (context) => RegistrationScreen(),
            loginScreen.idScreen: (context) => loginScreen(),
            MainScreen.idScreen: (context) => MainScreen(),
            AboutScreen.idScreen: (context) => AboutScreen(),
            AboutMenuPage.idScreen: (context) => AboutMenuPage(),
            forgotScreen.idScreen: (context) => forgotScreen(),
            OurRoot.idScreen: (context) => OurRoot(),
            recoveryRedirect.idScreen: (context) => recoveryRedirect(),
            EditProfileScreen.idScreen: (context) => EditProfileScreen(),
            SettingsPage.idScreen: (context) => SettingsPage(),
            LoginInfoPage.idScreen: (context) => LoginInfoPage(),
            PsychiatricTest.idScreen: (context) => PsychiatricTest(),
            SupportCenterPage.idScreen: (context) => SupportCenterPage(),
            TopicsPage.idScreen: (context) => TopicsPage(),
            EditAvatar.idScreen: (context) => EditAvatar(),
            BuckList.idScreen: (context) => BuckList(),
            TherapyPage.idScreen: (context) => TherapyPage(),
            PhoneVerification.idScreen: (context) => PhoneVerification(),
            EvaluationsScreen.idScreen: (context) => EvaluationsScreen(),
            HomeFeeder.idScreen: (context) => HomeFeeder(),
            SecretGroup.idScreen: (context) => SecretGroup(),
            OnboardingScreen.idScreen: (context) => OnboardingScreen(),
            //newNewScreen.idScreen: (context) => newNewScreen(),
            otherScreen.idScreen: (context) => otherScreen(),
          },
          debugShowCheckedModeBanner: false,
        ),
      );
  }
}
class InitializerWidget extends StatefulWidget {

  @override
  _InitializerWidgetState createState() => _InitializerWidgetState();
}
class _InitializerWidgetState extends State<InitializerWidget> {

  FirebaseAuth _auth;
  User _user;
  bool isLoading = true;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _auth = FirebaseAuth.instance;
    _user = _auth.currentUser;
    isLoading = false;
  }
  @override
  Widget build(BuildContext context) {
    return isLoading ? Scaffold(
      body: Center(
        child: CircularProgressIndicator(),
    ),
    ) : _user == null ? loginScreen() : MainScreen();
  }
}
Widget build(BuildContext context) {
  return FutureBuilder(
    future: Firebase.initializeApp(),
    builder: (context, snapshot) {
      if (snapshot.hasError) {
        return Scaffold(
          body: Center(child: Text(snapshot.error.toString(), style: TextStyle( fontFamily: "Avenir",),)),
        );
      }
      if (snapshot.connectionState == ConnectionState.waiting) {
        return Loading();
      }
      return MaterialApp(
      );
    },
  );
}

