class Bucket {
  String uid;
  String title;
  bool isComplete;

  Bucket({this.uid, this.title, this.isComplete});
}
