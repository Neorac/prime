// import 'package:flutter/material.dart';
//
//
// class BottomSheet{
//
//   showBottomSheet(context){
//
//     var screenHeight = MediaQuery.of(context).size.height *0.6;
//     var screenWidth = MediaQuery.of(context).size.width *1;
//
//     return showModalBottomSheet(
//         context: context,
//         builder: (BuildContext context){
//           return Container(
//             height: screenHeight,
//             width: screenWidth,
//           );
//     }
//     );
//   }
// }

//Navigator.pushNamedAndRemoveUntil(context, AboutMenuPage.idScreen, (route) => false);